#include "MyCppClass.h"

void MyCppClass::Method1()
{

}