#pragma once
class MyCppClass
{
public:
	int a;
	void Method1();

	void Method2()
	{
	};
};

