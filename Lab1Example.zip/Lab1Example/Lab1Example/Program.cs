﻿namespace Lab1Example
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MyClass myClass = new MyClass();
            myClass.a = 1;
            myClass.Method();


            //Console.WriteLine("Hello, World!");
        }
    }
}
