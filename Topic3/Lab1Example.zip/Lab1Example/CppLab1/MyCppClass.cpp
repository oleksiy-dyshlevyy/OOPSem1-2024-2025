#include "MyCppClass.h"
#include <iostream>


void MyCppClass::Method1()
{
	//std::cout << "Hello World!\n";
}

int MyCppClass::Method2()
{
	//std::cout << 0;
	return 0;
}

int MyCppClass::GetA()
{
	return a;
}