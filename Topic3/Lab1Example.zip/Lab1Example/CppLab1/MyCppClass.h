#pragma once
class MyCppClass
{
private:
	int a;
public:
	int b;
	void Method1();
	int Method2();
	int GetA();
	//void Method2()
	//{
	//};
};


