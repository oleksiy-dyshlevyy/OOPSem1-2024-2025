﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab1Example
{
    internal class MyClass
    {
        protected int a;
       public void Method()
        {
            int a = 500;
            if (a > 0)
            {
                int b = 10;
            }
            /*this.*/a = 10;
            // b = 10000;

            Console.WriteLine("sdfds");
        }
    }
}
