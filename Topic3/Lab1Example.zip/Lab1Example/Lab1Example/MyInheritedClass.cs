﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab1Example
{
     class MyInheritedClass : MyClass
    {
        public void MyMethod() 
        {
            a = 10;
        }
    }
}
