﻿using ClassLibrary1;

namespace Lab1Example
{
    
    internal class Program
    {
        static int Func()
            { return 0; }
        static void Main(string[] args)
        {
            Class1 class1 = new Class1();

           Student mykailo = new Student();
            //mykailo.name = "mykhailo"; ;
            //mykailo.sname = "mykhailenko";
            //mykailo.age = 20; ;
            //mykailo.course = 2;
            //mykailo.marks[0] = 60;


            //mykailo.name = "Petro" ;
            //mykailo.course = 3;
            //mykailo.marks[0] = 100;
            mykailo.GetName();
            mykailo.CoursePlusOne();

            Student ivan = mykailo;


            // mykailo.marks['OOP'] = 100;


            MyClass myClass = new MyClass();
            //myClass.a = 1;
            myClass.Method();

            MyInheritedClass myInheritedClass = new MyInheritedClass();
            myInheritedClass.Method();
            myInheritedClass.a = 1;

            int x = Func();


            int[] arr;// = new int[x]; 
            arr = new int[10];

            string str = "Hello";
            Console.WriteLine(str);

            Console.WriteLine("Hello, World!");
        }
    }
}
