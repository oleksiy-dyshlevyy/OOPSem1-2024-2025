﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Lab1Example
{
    internal class Student
    {
        private string name;
        private string sname;
        private int age;
        private int course;

        private int []marks = new int[5];

        public Student()
        {
            name = "Petro";
            sname = "Petrenko";
            age = 50;
            course = 1;
        }
        public Student(string name, string sname, int age, int course)
        {
            this.name = name;
            this.sname = sname;
            this.age = age;
            this.course = course;
        }
        public Student(Student st)
        {
            name = st.name;
            sname = st.sname;
            age = st.age;
            course = st.course;
        }

        ~Student()
        { 
        }

        public enum Subjects {OOP, Phisics};

        public void CoursePlusOne()
        {
            course++;
        }

        public string GetName()
        {
            return /*this.*/name;
        }

        private void ChangeAttributes()
        {
            name = "Petro";
            sname = "Petrenko";
            age = 50;
            course = 1;
        }

        protected void ChangeCourse(int course)
        {
            this.course = course;
        }
    }
}
