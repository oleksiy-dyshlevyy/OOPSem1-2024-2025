#pragma once
class LibClass
{
};

