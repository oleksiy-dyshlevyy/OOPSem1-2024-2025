// StaticLib1.cpp : Defines the functions for the static library.
//

#include "pch.h"
#include "framework.h"
#include "LibClass.h"

// TODO: This is an example of a library function
void fnStaticLib1()
{
}
