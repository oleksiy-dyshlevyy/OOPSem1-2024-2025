﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPParametersOperators
{
    public class Hour
    {
        int value;
        public Hour(int hr)
        {
            this.value = hr % 24;
        }

        public static implicit operator int(Hour from)
        {
            return from.value;
        }

        public static explicit operator Hour(int from)
        {
            return new Hour(from);
        }

    }
}
