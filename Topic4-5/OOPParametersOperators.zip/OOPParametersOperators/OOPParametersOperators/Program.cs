﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOPParametersOperators
{
    class Program
    {
        public static void Method(ref Sqr p, ref int a)
        {
          a = 100;
            Sqr o = new Sqr();
                  o.Side1 = 10000;
            p = o;
             p.Side1 = 10;
        }

        public static Sqr Method1(int a, int b = 0, params int[] c)
        {
            Sqr s = new Sqr();
            //          s.side = b;
            a = 100;
            return s;
        }

        public static void Method2(int a, int b = 0, params int[] c)
        {

            a = 1000;
            //  b = 500;
            
            c[0] = 4;
            c[1] = 7;
            c[10] = 8;
        }
       
        public static void Method3(Sqr sqr)
        {
            sqr.Side1 = 1000;
            sqr = new Sqr();
            sqr.Side1 = 500;

            Sqr sqr5 = new Sqr();
            sqr5.Side1 = 1500;
            sqr = sqr5;

        }

        public static void Method4(int a)
        {
            a = 10;
        }
        static void Main(string[] args)
        {
            
            int result = 5;

            Method4(result);
            Sqr sqr1 = new Sqr();
            Sqr sqr2 = new Sqr(5);

        //    sqr1.b = true;

            sqr1.Side1 = 3;
            double r = sqr1.Side1;

            r = sqr1.Side;
            sqr1.Side = -5;

           // Sqr sqr5 = new Sqr { b = true, c = 10 };

            Method3(sqr1);

            Method(ref sqr1, ref result);
            Method2(1,2,result);

            sqr2 = Method1(a: result, b: result * 2, c: new int[] { result * 3, result * 4 });
           
            Method2(result, result * 2, result * 3, result * 4);

            Sqr sqr3 = sqr1 + sqr2;

            bool b = true;

      
      

            ++sqr1;

            bool bb = !sqr2;

            sqr1.Side = 5;
            Console.WriteLine(sqr1.Side);

            // System.Object o = sqr3 as object;

            if (sqr1 != sqr2)
            { }

            Hour hour = new Hour(4);
            int h = hour;
            h++;
            hour = (Hour)h;

            Employee employee1 = new Employee();
            Employee employee2 = new Employee()
            {
                firstName = "Ivan",
                lastName = "Ivanov",
                birthDate = new Date(),
                hireDate = new Date(20, 10, 2017)
                //{
                //    day = 20,
                //    month = 10,
                //    year = 2017
                //},
            };
        }
    }
}
