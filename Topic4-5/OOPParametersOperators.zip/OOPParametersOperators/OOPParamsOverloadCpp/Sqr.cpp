#include "stdafx.h"
#include "Sqr.h"


Sqr::Sqr()
{
	side = 1;
}
Sqr::Sqr(int parside) :side(parside)
{
	//side = parside;
}

int Sqr::P()
{
	return side * 4;
}

int Sqr::Get()
{
	return side;
}

void Sqr::Set(int parside)
{
	if (parside > 0)
	{
		side = parside;
	}
}

Sqr Sqr::operator-(Sqr s1)
{
	Sqr sqr;
	sqr.side = side - s1.side;
	return sqr;
}

Sqr Sqr::operator-(int i1)
{
	Sqr sqr;
	sqr.side = side - i1;
	return sqr;
}

bool Sqr::operator==(Sqr s1)
{
	if (side == s1.side)
	{
		return true;
	}
	else
	{
		return false;
	}
	//return false;
}

bool Sqr::operator!()
{
	if (side != 0)
	{
		return true;
	}
	else
	{
		return false;
	}
	//return false;
}



Sqr Sqr:: operator++(int i)
{
	Sqr s(*this);
	++(*this);
	//s.side += i;
	return s;
}

Sqr::~Sqr()
{
}

Sqr operator+(Sqr s1, Sqr s2)
{
	Sqr sqr;
	sqr.side = s1.side + s2.side;
	return sqr;
}

Sqr operator+(int i1, Sqr s2)
{
	Sqr sqr;
	sqr.side = i1 + s2.side;
	return sqr;
}



Sqr& operator++(Sqr s)
{
	s.side++;
	return s;
}

//Sqr& operator++(Sqr s, int i)
//{
//	s.side += i;
//	return s;
//}

int S(Sqr sqr)
{
	return sqr.side;
}