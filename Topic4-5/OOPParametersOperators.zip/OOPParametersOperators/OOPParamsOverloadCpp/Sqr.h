#pragma once
class Sqr
{
private:
	int side;

public:
	int side2;

	Sqr();
	Sqr(int parside);
	int P();
	int Get();
	void Set(int parside);
	
	int Func() const { return 0; }	 // const function

	Sqr operator-(Sqr);
	Sqr operator-(int);
	bool operator! ();

	bool operator== (Sqr);

	friend Sqr operator+(Sqr, Sqr);
	friend Sqr operator+(int, Sqr);
	friend Sqr& operator++(Sqr);
	//friend Sqr& operator++(Sqr, int);
	Sqr operator++(int);

	friend int S(Sqr);

	~Sqr();
};

