#include "stdafx.h"
#include "Base.h"


Base::Base()
{
}

Base::Base(int i)
{ 
	i1 = i;
}

Base::~Base()
{
}

void Base::Method1()
{
}
