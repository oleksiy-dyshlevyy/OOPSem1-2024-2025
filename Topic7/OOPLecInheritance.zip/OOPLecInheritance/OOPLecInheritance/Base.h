#pragma once
class Base
{
public:
	int i1;
	Base();
	Base(int i);
	~Base();

	void Method1();
};

