#include "stdafx.h"
#include "Base11.h"


Base11::Base11()
{
}

Base11::Base11(int i) : Base(i)
{  
}

Base11::~Base11()
{
}

//void Base::Method1()
//{
//}
