#pragma once
#include "Base.h"

class Base11 :
	public Base
{
public:
	Base11();
	Base11(int i);
	
	//void Method1();

	~Base11();
};

