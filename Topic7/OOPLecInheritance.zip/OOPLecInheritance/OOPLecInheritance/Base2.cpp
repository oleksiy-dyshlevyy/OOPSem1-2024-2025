#include "stdafx.h"
#include "Base2.h"


Base2::Base2()
{
}

Base2::Base2(int i)
{
	i2 = i; 
}

Base2::~Base2()
{
}

void Base2::Method2()
{
}