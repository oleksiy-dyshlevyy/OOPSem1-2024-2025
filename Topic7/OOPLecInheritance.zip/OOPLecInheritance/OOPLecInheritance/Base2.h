#pragma once
class Base2
{
public:
	int i2;
	Base2();
	Base2(int i);

	void Method2();
	//void Method1();
	~Base2();
};

