#include "stdafx.h"
#include "Derived.h"


Derived::Derived()
{
}

Derived::Derived(int i) : Base(i + 10), Base2(i + 20)
{
	i3 = i;
}

Derived::~Derived()
{
}

void Derived::Method3() 
{
}
