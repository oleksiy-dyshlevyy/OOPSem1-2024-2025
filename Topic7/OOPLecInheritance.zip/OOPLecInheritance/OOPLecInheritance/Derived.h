#pragma once
#include "Base.h"
#include "Base2.h"

class Derived : public Base, public Base2
{
public:
	int i3;
	Derived();
	~Derived();

	Derived(int i);
	void Method3();
};

