#include "stdafx.h"
#include "Derived1.h"


Derived1::Derived1()
{
}


Derived1::~Derived1()
{
}

void Derived1::Method4()
{
}
