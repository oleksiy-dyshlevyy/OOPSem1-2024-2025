#pragma once
#include "Base.h"
class Derived1 :
	public Base
{
public:
	Derived1();
	~Derived1();

	int i4;
	void Method4();
};

