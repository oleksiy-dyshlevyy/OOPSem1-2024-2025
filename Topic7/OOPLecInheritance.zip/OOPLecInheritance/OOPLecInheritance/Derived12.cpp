#include "stdafx.h"
#include "Derived12.h"


Derived12::Derived12()
{
}


Derived12::~Derived12()
{
}

void Derived12::Method6()
{
	sum = i4 + i5;
	Derived1::Method1();
	//sum = i1;  // error
	sum = Derived1::i1 + Derived2::i1;
};

