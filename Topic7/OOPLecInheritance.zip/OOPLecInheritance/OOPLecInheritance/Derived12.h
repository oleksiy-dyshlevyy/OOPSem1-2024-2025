#pragma once
#include "Derived1.h"
#include "Derived2.h"

class Derived12 :public Derived1, public Derived2
{
public:
	Derived12();
	~Derived12();

	int sum;
	void Method6();
};

