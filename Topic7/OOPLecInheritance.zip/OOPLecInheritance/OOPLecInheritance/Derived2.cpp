#include "stdafx.h"
#include "Derived2.h"


Derived2::Derived2()
{
}


Derived2::~Derived2()
{
}

void Derived2::Method5()
{
}
