#pragma once
#include "Base.h"
class Derived2 :
	public Base
{
public:
	Derived2();
	~Derived2();

	int i5;
	void Method5();
};

