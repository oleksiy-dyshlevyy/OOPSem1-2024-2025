#include "stdafx.h"
#include "Derived3.h"


Derived3::Derived3() :Base(3)
{
}

Derived3::~Derived3()
{
}

void Derived3::Method4()
{
}
