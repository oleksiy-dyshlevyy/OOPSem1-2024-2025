#pragma once
#include "Base.h"

class Derived3 : virtual public Base
{
public:
	int i4;
	~Derived3();

	Derived3();
	void Method4();
};

