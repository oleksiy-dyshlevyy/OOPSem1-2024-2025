#include "stdafx.h"
#include "Derived34.h"


Derived34::Derived34()
{
	//i1 = 100;
}


Derived34::~Derived34()
{
}

void Derived34::Method6()
{
	sum = i4 + i5;
	
	sum = Derived3::i1 + Derived4::i1;

	sum = i1;
};
