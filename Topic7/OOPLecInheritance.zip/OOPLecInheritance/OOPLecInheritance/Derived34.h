#pragma once

#include "Derived3.h"
#include "Derived4.h"

class Derived34 :public Derived3, public Derived4
{
public:
	Derived34();
	~Derived34();

	int sum;
	void Method6();
};

