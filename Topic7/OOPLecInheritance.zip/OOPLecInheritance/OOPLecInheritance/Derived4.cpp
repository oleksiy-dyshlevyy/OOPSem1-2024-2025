#include "stdafx.h"
#include "Derived4.h"


Derived4::Derived4() :Base(4)
{
}


Derived4::~Derived4()
{
}

void Derived4::Method5()
{
}
