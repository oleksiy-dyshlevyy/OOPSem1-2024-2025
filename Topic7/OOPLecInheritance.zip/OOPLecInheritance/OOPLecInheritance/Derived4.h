#pragma once
#include "Base.h"

class Derived4 : virtual public Base
{
public:
	int i5;
	Derived4();
	~Derived4();
	void Method5();
};

